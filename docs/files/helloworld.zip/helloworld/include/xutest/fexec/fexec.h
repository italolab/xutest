#ifndef EXEC_FUNC_H
#define EXEC_FUNC_H

#include <string>

using std::string;

namespace fexec {

    void exec( string funcName );

}

#endif