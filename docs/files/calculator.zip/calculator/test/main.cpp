#include "calc/calctests.h"

#include <xutest/xutest.h>

int main() {
    RUN_ALL_TEST_CASES();
    return 0;
}